# AgaveDB

All significant changes will be recorded in this document

## 0.1.1 - Standalone Release

* Added
    * Packaged for PyPi
    
* Changed
    * Nothing

* Removed
    * Nothing

## 0.1.0 - First release

* Added

* Changed

* Removed
